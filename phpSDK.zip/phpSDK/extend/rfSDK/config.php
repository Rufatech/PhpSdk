<?php

#appID 商家id
const APP_ID  = "s6VvWTGL";

#secret 鉴权密钥
const ACCESS_SECRET = "887fe05c5d24c8d42bb4730c4d63cfc243f5c5b3";

#上链文件目录
const FILE_PATH = "./upload";

#下载文件目录
const DOWNLOAD_PATH = "./download";

#获取认证链接
const APPLOGIN_URL = "http://openapi.dev.rufa.tech/openapi/evidence/applogin";

#文件存证链接
const UPLOAD_URL = "http://openapi.dev.rufa.tech/openapi/evidence/upload";

#如法证书下载链接
const RF_D_URL = "http://openapi.dev.rufa.tech/openapi/evidence/rf/d/";

#安络司法证书下载链接
const ZS_D_URL = "http://openapi.dev.rufa.tech/openapi/evidence/zs/d/";

#源文件下载链接
const D_URL = "http://openapi.dev.rufa.tech/openapi/evidence/d/";

#查询链接
const QUERY_URL = "http://openapi.dev.rufa.tech/openapi/evidence/info";

#存证开放校验
const VERIFY_URL = "http://openapi.dev.rufa.tech/openapi/evidence/verify";