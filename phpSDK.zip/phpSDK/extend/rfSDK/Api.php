<?php
namespace rfSDk;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

require_once "config.php";

class Api {
    /**
     * 1、获取认证
     * @return mixed
     */
    public function getAccessToken(){
        $params = [
            'appId' => APP_ID,
            'accessSecret' => ACCESS_SECRET
        ];
        return $this->httpRequest(APPLOGIN_URL, 'post', json_encode($params), ['Content-Type:application/json; charset=utf-8']);
    }


    /**
     * 2、文件存证
     * @param $args
     * @return mixed
     */
    public function upload($args){
        $params = [
            [
                'name' => 'type',
                'contents' => $args['type']
            ],
            [
                'name' => 'fileInfo',
                'contents' => $args['fileInfo']
            ],
        ];

        if (!file_exists(FILE_PATH)) {
            mkdir(FILE_PATH, 0777);
        }
        //查找目录下文件
        $handler = opendir(FILE_PATH);
        while (($filename = readdir($handler)) !== false)
        {
            //判断去掉空名字文件
            $fileInfo = explode(".", $filename);

            // 务必使用!==，防止目录下出现类似文件名“0”等情况
            if (count(array_filter($fileInfo)) >= 2 && $filename !== "." && $filename !== "..")
            {
                $arr = [
                    'name' => 'file',
                    'contents' => fopen(FILE_PATH . "/" . $filename, 'r')
                ];
                array_push($params, $arr);
            }
        }

        closedir($handler);

        $token = $this->getToken();
        if ($token == "") {
            return "凭证无效";
        }

        $header = array(
            'Authorization' => $token
        );

        return $this->uploadFile(UPLOAD_URL, $params, $header);
    }

    /**
     * 3、下载安络司法存证证书
     * @param $args
     * @return mixed
     */
    public function downloadAL($args){
        $token = $this->getToken();
        if ($token == "") {
            return "凭证无效";
        }

        $header = array(
            'Authorization:' . $token
        );

        return $this->saveFile(ZS_D_URL . $args['fileId'], $header);
    }

    /**
     * 4、下载如法存证证书
     * @param $args
     * @return mixed
     */
    public function downloadRF($args){
        $token = $this->getToken();
        if ($token == "") {
            return "凭证无效";
        }

        $header = array(
            'Authorization:' . $token
        );

        return $this->saveFile(RF_D_URL . $args['fileId'], $header);
    }

    /**
     * 5、下载源文件
     * @param $args
     * @return mixed
     */
    public function download($args){
        $token = $this->getToken();
        if ($token == "") {
            return "凭证无效";
        }

        $header = array(
            'Authorization:' . $token
        );

        return $this->saveFile(D_URL . $args['fileId'], $header);
    }

    /**
     *6、查询存证详细信息
     * @param $args
     * @return mixed
     */
    public function info($args){
        $params = [
            'fileId' => $args['fileId'],
        ];

        $token = $this->getToken();
        if ($token == "") {
            return "凭证无效";
        }

        $header = array(
            'Authorization:' . $token
        );
        $client = new Client();
        return $this->httpRequest(QUERY_URL, 'POST', $params, $header);
    }

    /**
     * 7、存证开放校验
     * @param $args
     * @return mixed
     */
    public function verify($args){
        $params = [
            'fileId' => isset($args['fileId']) ? $args['fileId'] : "",
            'fileSha256' => isset($args['fileSha256']) ? $args['fileSha256'] : "",
            'transHash' => isset($args['transHash']) ? $args['transHash'] : ""
        ];

        $token = $this->getToken();
        if ($token == "") {
            return "凭证无效";
        }

        $header = array(
            'Authorization:' . $token
        );
        return $this->httpRequest(VERIFY_URL, 'post', $params, $header);
    }


    /**
     * CURL请求
     * @param $url 请求url地址
     * @param $method 请求方法 get post
     * @param null $postfields post数据数组
     * @param array $headers 请求header信息
     * @param bool|false $debug  调试开启 默认false
     * @return mixed
     */
    private function httpRequest($url, $method, $postfields = null, $headers = array(), $debug = false) {
        $method = strtoupper($method);
        $ci = curl_init();
        /* Curl settings */
        curl_setopt($ci, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($ci, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0");
        curl_setopt($ci, CURLOPT_CONNECTTIMEOUT, 60); /* 在发起连接前等待的时间，如果设置为0，则无限等待 */
        curl_setopt($ci, CURLOPT_TIMEOUT, 7); /* 设置cURL允许执行的最长秒数 */
        curl_setopt($ci, CURLOPT_RETURNTRANSFER, true);
        switch ($method) {
            case "POST":
                curl_setopt($ci, CURLOPT_POST, true);
                if (!empty($postfields)) {
                    $tmpdatastr = is_array($postfields) ? http_build_query($postfields) : $postfields;
                    curl_setopt($ci, CURLOPT_POSTFIELDS, $tmpdatastr);
                }
                break;
            default:
                curl_setopt($ci, CURLOPT_CUSTOMREQUEST, $method); /* //设置请求方式 */
                break;
        }
        $ssl = preg_match('/^https:\/\//i',$url) ? TRUE : FALSE;
        curl_setopt($ci, CURLOPT_URL, $url);
        if($ssl){
            curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, FALSE); // https请求 不验证证书和hosts
            curl_setopt($ci, CURLOPT_SSL_VERIFYHOST, FALSE); // 不从证书中检查SSL加密算法是否存在
        }
        //curl_setopt($ci, CURLOPT_HEADER, true); /*启用时会将头文件的信息作为数据流输出*/
        //curl_setopt($ci, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ci, CURLOPT_MAXREDIRS, 2);/*指定最多的HTTP重定向的数量，这个选项是和CURLOPT_FOLLOWLOCATION一起使用的*/
        curl_setopt($ci, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ci, CURLINFO_HEADER_OUT, true);
        /*curl_setopt($ci, CURLOPT_COOKIE, $Cookiestr); * *COOKIE带过去** */
        $response = curl_exec($ci);
        $requestinfo = curl_getinfo($ci);
        $http_code = curl_getinfo($ci, CURLINFO_HTTP_CODE);

        if ($debug) {
            echo "=====post data======\r\n";
            var_dump($postfields);
            echo "=====info===== \r\n";
            print_r($requestinfo);
            echo "=====response=====\r\n";
            print_r($response);
        }
        curl_close($ci);

        return $response;
    }

    /**
     * 下载并保存文件
     * @param $url
     * @param array $headers
     * @param bool $debug
     * @return string
     */
    private function saveFile($url, $headers = array(), $debug = false)
    {
        $method = 'GET';
        $ci = curl_init();
        /* Curl settings */
        curl_setopt($ci, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($ci, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0");
        curl_setopt($ci, CURLOPT_CONNECTTIMEOUT, 60); /* 在发起连接前等待的时间，如果设置为0，则无限等待 */
        curl_setopt($ci, CURLOPT_TIMEOUT, 7); /* 设置cURL允许执行的最长秒数 */
        curl_setopt($ci, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ci, CURLOPT_CUSTOMREQUEST, $method);
        $ssl = preg_match('/^https:\/\//i',$url) ? TRUE : FALSE;
        curl_setopt($ci, CURLOPT_URL, $url);
        if($ssl){
            curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, FALSE); // https请求 不验证证书和hosts
            curl_setopt($ci, CURLOPT_SSL_VERIFYHOST, FALSE); // 不从证书中检查SSL加密算法是否存在
        }
        curl_setopt($ci, CURLOPT_HEADER, true); /*启用时会将头文件的信息作为数据流输出*/
        //curl_setopt($ci, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ci, CURLOPT_MAXREDIRS, 2);/*指定最多的HTTP重定向的数量，这个选项是和CURLOPT_FOLLOWLOCATION一起使用的*/
        curl_setopt($ci, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ci, CURLINFO_HEADER_OUT, true);
        /*curl_setopt($ci, CURLOPT_COOKIE, $Cookiestr); * *COOKIE带过去** */
        $response = curl_exec($ci);
        $requestinfo = curl_getinfo($ci);
        $size = curl_getinfo($ci, CURLINFO_HEADER_SIZE);
        $http_code = curl_getinfo($ci, CURLINFO_HTTP_CODE);
        $header = substr($response,0, $size);

        if ($debug) {
            echo "=====info===== \r\n";
            print_r($requestinfo);
            echo "=====response=====\r\n";
            print_r($response);
        }
        curl_close($ci);

        //return $response;

        $receiveFilePath = DOWNLOAD_PATH;

        if (!file_exists($receiveFilePath)){
            mkdir($receiveFilePath, 0777);
        }
        if(preg_match('/Content-Disposition: .*filename=(.+)/', $response, $matches)) { //([^ +\s*]+)
            $receiveFile = $receiveFilePath . "/" . iconv("gb2312", "utf-8", trim($matches[1]));
            $response = substr($response, $size);
            file_put_contents($receiveFile, $response, true);
        } else {
            $receiveFile = "";
        }

        return $receiveFile;
    }

    /**
     * 上传文件
     * @param $url
     * @param $data
     * @param $headers
     * @return bool|string
     */
    private function uploadFile($url, $data, $headers){
        $client = new Client();
        try {
            $response = $client->post($url, [
                'multipart' => $data,
                'headers' => $headers,
                //'debug'   => true,
                //'verify'  => true,
            ]);
            return $response->getBody();
        } catch (RequestException $e) {
            //
            if ($e->hasResponse()) {
                echo $e->getCode();
                echo $e->getResponse()->getBody();
            }
        }
    }

    private function getToken() {
        //可以放在缓存里面
        $result = $this->getAccessToken();
        $data = json_decode($result, true);
        if (isset($data['code']) && $data['code'] == 0) {
            return $data['data']['accessToken'];
        } else {
            return "";
        }
    }
}