<?php
// 应用公共文件

function jsonOk($data){
    header('Content-Type:application/json; charset=utf-8');
    $return = [
        'code' => 'OK',
        'msg' => '成功',
        'data' => $data
    ];
    exit(json_encode($return));
}

function jsonError($msg) {
    header('Content-Type:application/json; charset=utf-8');
    $msg ? :$msg = '访问失败';
    $return = [
        'code' => 'error',
        'msg' => $msg
    ];

    exit(json_encode($return));
}
