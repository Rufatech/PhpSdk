<?php
namespace app\controller;

use app\BaseController;
use rfSDk\Api;
use think\facade\Route;

class Index extends BaseController
{
    public function index()
    {
        /*$str = "<a href='". Route::buildUrl('token')."'>1、获取token</a></br>";
        $str .= "<a href='". Route::buildUrl('upload')."'>2、文件存证</a></br>";
        $str .= "<a href='". Route::buildUrl('download_al')."'>3、下载安络司法存证证书</a></br>";
        $str .= "<a href='". Route::buildUrl('download_rf')."'>4、下载如法存证证书</a></br>";
        $str .= "<a href='". Route::buildUrl('download')."'>5、下载源文件</a></br>";
        $str .= "<a href='". Route::buildUrl('info')."'>6、查询存证详细信息</a></br>";*/
        //$str .= "<a href='".\think\facade\Route::buildUrl('upload')."'>7、存证开放校验</a>";
        $str = "<a href='/index.php/index/token.html'>1、获取token</a></br>";
        $str .= "<a href='/index.php/index/upload.html'>2、文件存证</a></br>";
        $str .= "<a href='/index.php/index/download_al.html'>3、下载安络司法存证证书</a></br>";
        $str .= "<a href='/index.php/index/download_rf.html'>4、下载如法存证证书</a></br>";
        $str .= "<a href='/index.php/index/download.html'>5、下载源文件</a></br>";
        $str .= "<a href='/index.php/index/info.html'>6、查询存证详细信息</a></br>";
        echo $str;
    }

    public function token()
    {
        $Api = new Api();
        $result = $Api->getAccessToken();
        $data = json_decode($result, true);
        if (isset($data['code']) && $data['code'] == 0) {
            echo "成功获取凭证:" . $data['data']['accessToken'] . "; 有效时间:" . $data['data']['expires'] . "s；消息：" . $data['msg'];
        } else {
            echo "获取凭证失败,消息：" . $data['msg'];
        }
    }

    public function upload()
    {
        $fileInfo = [
            "applyName"=> "合同",
            "fileLabelNo"=> 41,
            "fileTypeId"=> 4,
            "filename"=> "财税.docx",
            "orderNo"=> "php202012311645"
        ];
        $Api = new Api();
        $params = [
            'type' => 0,
            'fileInfo' => '{"applyName": "京东金融","fileLabelNo": 41,"fileTypeId": 4,"filename": "1605772682688.jpg","orderNo": "php202012311645"}',
        ];
        $result = $Api->upload($params);
        $data = json_decode($result, true);
        if (isset($data['code']) && $data['code'] == 0) {
            echo $result;
        } else {
            echo "上传失败,消息：" . (isset($data['msg']) ? $data['msg'] : $data['message']);
        }
    }

    public function download_al()
    {
        $Api = new Api();
        $params = [
            'fileId' => '439918249E95D9A160968'
        ];
        $result = $Api->downloadAL($params);
        if ($result) {
            echo "文件下载成功:" . $result;
        } else {
            echo "文件下载失败";
        }
    }

    public function download_rf()
    {
        $Api = new Api();
        $params = [
            'fileId' => '439918249E95D9A160968'
        ];
        $result = $Api->downloadRF($params);
        if ($result) {
            echo "文件下载成功:" . $result;
        } else {
            echo "文件下载失败";
        }
    }

    public function download()
    {
        $Api = new Api();
        $params = [
            'fileId' => '439918249E95D9A160968'
        ];
        $result = $Api->download($params);
        if ($result) {
            echo "文件下载成功:" . $result;
        } else {
            echo "文件下载失败";
        }
    }

    public function info()
    {
        $Api = new Api();
        $params = [
            'fileId' => "439918249E95D9A160968"
        ];
        $result = $Api->info($params);
        $data = json_decode($result, true);
        if (isset($data['code']) && $data['code'] == 0) {
            echo "获取成功:" . $data['data']['fileId'] . "; 文件名称:" . $data['data']['filename'] . "；应用名称：" . $data['data']['applyName'];
        } else {
            echo "获取失败,消息：" . $data['msg'];
        }
    }

    public function verify()
    {
        $Api = new Api();
        $params = [
            'fileId' => "439918249E95D9A160968",
            'transHash' => 'f0969e69ffcbfe2f80421487455e339039052d20d2d26c770b58228dfe2ba7d5'
        ];
        $result = $Api->verify($params);
        $data = json_decode($result, true);
        if (isset($data['code']) && $data['code'] == 0) {
            echo "获取成功:" . $data['data']['fileId'] . "; 文件名称:" . $data['data']['filename'] . "；应用名称：" . $data['data']['applyName'];
        } else {
            echo "获取失败,消息：" . $data['msg'];
        }
    }
    
}
